#!/bin/bash
# student's name = Hod Perez
# code = s9
# class code = TMagen773632
# lecturer's name = Erel Regev

#let only root user to continue, define variables for other functions
function CHECK_IF_ROOT()
{
	start_time=$(date)
	whoami=$(whoami)
	
	if [ "$whoami" != "root" ]; then
	echo -e "\nyou have to be root for continue... exiting"
	exit
	fi
	
	y=0
	x=0
	INITIAL_PATH=$(pwd)
	echo
	CHECK_IF_FILE_EXIST
	
	#NAME_OF_DIRECTORY
}

#check if file exist, afer 3 times the user give wrong path, it exit
function CHECK_IF_FILE_EXIST()
{
	read -p "Please enter full path to the memory file you want to investigate: " path
	
	if [ -f "$path" ]
	then
		NAME_OF_DIRECTORY
	else
		((y++))
		if [ "$y" -eq 3 ]
		then
			echo -e "\nyou are giving me wrong paths, exiting..."
			exit
		fi
		echo -e "\nthis path is not exist"
		sleep 0.1
		CHECK_IF_FILE_EXIST
	fi
}


#ask the user for name for the directory, if the user wrong 3 times, it helps him and determine a default name for the process, and creates the directory
NAME_OF_DIRECTORY()
{
	read -p "please insert the name of the directory you want for the process: " name_of_directory
	if [ -d "./$name_of_directory" ]
	then
		((x++))
		if [ "$x" -eq 3 ]
		then
			echo -e "i see you are hardening to define a name that not exist\nso i will create a name bymyself called \"forensics\" if not exist"
			sleep 2
			name_of_directory="forensics"
			mkdir "$INITIAL_PATH"/"$name_of_directory" > /dev/null 2>&1
			TOOLS
			return
		fi
		echo "please insert another name, this name is already taken"
		NAME_OF_DIRECTORY
	else
		echo "creating a directory called $name_of_directory if not exist"
		mkdir "$INITIAL_PATH"/"$name_of_directory" > /dev/null 2>&1
		TOOLS
	fi
	
}


LIST_OF_PACKETS=("binutils" "binwalk" "foremost" "bulk-extractor")

#installing volatality if not exist, and needed packets for the process
function TOOLS()
{
	if ! [ -d "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5 ]; then
		echo -e "\ninstalling volataity version 2.5"
		cd "$INITIAL_PATH"/"$name_of_directory" && git clone https://github.com/hodperez/volatality-2.5.git
		if ! [ -d "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5 ]; then
			echo "Error, volatality is not installed"
		else
			echo -e "volatality have installed successfully\n"
		fi
	else
		echo -e "\nvolatality is already on your system\n"
	fi
	
	cd "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5 && chmod +x volatility_2.5_linux_x64
	
	
	for package in "${LIST_OF_PACKETS[@]}"; do
		dpkg -s "$package" >/dev/null 2>&1 ||
		(echo -e "[*] starting to install the package $package.." &&
		sudo apt-get install "$package" -y >/dev/null 2>&1)
		echo "The package $package is installed on remote host."
	done
	
	filename=$(basename "$path")
	
	INFO_EXTRACTION
}

#extracts files and search for a pcap file and info on the pcap file if exist
function INFO_EXTRACTION()
{
	bulk_extractor "$path" -o "$INITIAL_PATH"/"$name_of_directory"/bulk_extractor > /dev/null 2>&1
	foremost "$path" -o "$INITIAL_PATH"/"$name_of_directory"/foremost > /dev/null 2>&1
	cd "$INITIAL_PATH"/"$name_of_directory" && binwalk -e --run-as=root "$path" > /dev/null 2>&1
	name_of_pcap_file=$(cd "$INITIAL_PATH"/"$name_of_directory"/bulk_extractor && ls | grep -i *.pcap)
	if [ "$name_of_pcap_file" == "" ]; then
		echo "\nthere is not pcap file"
	else
		size_of_pcap_file=$(cd "$INITIAL_PATH"/"$name_of_directory"/bulk_extractor && ls -l $name_of_pcap_file | awk '{print $5}')
		location_of_pcap_file="$INITIAL_PATH"/"$name_of_directory"/bulk_extractor/"$name_of_pcap_file"
		echo -e "\nthe name of the pcap file is $name_of_pcap_file\nthe size of the pcap file is $size_of_pcap_file bytes\nthe location of the pcap file is in \"$location_of_pcap_file\""
	fi
	
	HUMAN_READABLE_FILES
}

#search for info on users and passwords
function HUMAN_READABLE_FILES()
{
	cd "$INITIAL_PATH"/"$name_of_directory" && : > human_readable_file.txt
	strings "$path" | grep -i password >> "$INITIAL_PATH"/"$name_of_directory"/human_readable_file.txt
	strings "$path" | grep -i username >> "$INITIAL_PATH"/"$name_of_directory"/human_readable_file.txt
	strings "$path" | grep -i "\.exe" >> "$INITIAL_PATH"/"$name_of_directory"/human_readable_file.txt
	cd "$INITIAL_PATH"/"$name_of_directory" && exe_extension_files=$(find -type f -name "*.exe")
	for exe_file in $exe_extension_files
	do
		strings $exe_file | grep -i password >> "$INITIAL_PATH"/"$name_of_directory"/human_readable_file.txt
		strings $exe_file | grep -i username >> "$INITIAL_PATH"/"$name_of_directory"/human_readable_file.txt
	done
	
	echo -e "\nThe human readable text is in the next location: \"$INITIAL_PATH/$name_of_directory/human_readable_file.txt\""
	
	CHECK_VOL
}

#check if volatality can act on the given file
function CHECK_VOL()
{
	extension="${filename##*.}"
	if [[ "$extension" == "mem" || "$extension" == "raw" || "$extension" == "vmem" || "$extension" == "dmp" || "$extension" == "bin" || "$extension" == "dd" ]]; then
		echo -e "\nrunning volatality...\n"
		VOLATALITY
	else
		echo "voltality does not support $extension files"
		LAST_FUNCTION
	fi
}

#display data been extracted on the memory file using volatality
function VOLATALITY()
{
	profile=$(cd "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5 && ./volatility_2.5_linux_x64 -f "$path" imageinfo 2>/dev/null | grep -i suggested | awk '{print $4}' | sed 's/,//g')
	running_processes=$(cd "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5 && ./volatility_2.5_linux_x64 -f "$path" --profile=$profile pslist 2>/dev/null)
	sleep 1
	echo -e "the running proccesses are:\n"
	echo "$running_processes"
	sleep 2
	net_connections=$(cd "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5 && ./volatility_2.5_linux_x64 -f "$path" --profile=$profile connscan 2>/dev/null)
	echo -e "\nthe network connections are:\n" 
	echo "$net_connections"
	cd "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5 && ./volatility_2.5_linux_x64 -f "$path" --profile=$profile hivelist 2>/dev/null > "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5/hivelist.txt
	if [ -s "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5/hivelist.txt ]
	then
		sleep 1
		echo -e "\nthe hivelist is:\n"
		cat hivelist.txt
	fi
	cd "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5 && ./volatility_2.5_linux_x64 -f "$path" --profile=$profile hashdump 2>/dev/null > "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5/hashdump.txt
	if [ -s "$INITIAL_PATH"/"$name_of_directory"/volatality-2.5/hashdump.txt ]
	then
	sleep 1
	echo -e "\nsucceeded successfuly to extract hashes of users\n" 
	cat hashdump.txt
	sleep 1
	echo -e "\nstarting to crack the password...\n"
	john hashdump.txt
	fi
	LAST_FUNCTION
}

#zip the files, display the time the all process took and the amount of files
function LAST_FUNCTION()
{
	cd "$INITIAL_PATH"/"$name_of_directory" && zip -r "$name_of_directory".zip "$INITIAL_PATH"/"$name_of_directory" 1> /dev/null
	echo -e "\nthe process started in $start_time"
	end_time=$(date)
	echo "the process ended in $end_time"
	time_of_start=$(echo "$start_time" | awk '{print $4}')
	time_of_end=$(echo "$end_time" | awk '{print $4}')
	start_seconds=$(date -d "$start_time" +%s)
	end_seconds=$(date -d "$end_time" +%s)
	elapsed_time=$((end_seconds - start_seconds))
	echo "the process lasted $elapsed_time seconds"
	name_of_files=$(find "$INITIAL_PATH"/"$name_of_directory" -type d -name "volatality-2.5" -prune -o -type f -print)
	echo "$name_of_files" > "$INITIAL_PATH"/"$name_of_directory"/name_of_files.txt
	echo "there is $(echo "$name_of_files" | wc -l) found files"
}



#shows graphic paint
figlet -f slant "Forensic investigation"
#starts with the first function
CHECK_IF_ROOT
